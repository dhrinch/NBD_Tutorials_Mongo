printjson(db.collection.deleteMany( { "height" : {$lt : "190" }}))
printjson(db.collection.find({"height" : {$lt : "190"}}).toArray())