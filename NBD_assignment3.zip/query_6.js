printjson(db.collection.insert(
{
	"sex" : "Male",
	"first_name" : "Dennis",
	"last_name" : "Grinchenko",
	"job" : "Test Engineer",
	"email" : "s22362@pjwstk.edu.pl",
	"location":
	{
		"city" : "Warsaw",
		"address" : 
		{
			"streetname" : "Kubusia Puchatka",
			"streetnumber" : "12"
		} 
	},
"description" : "Lorem ipsum dolor sit amet", 
"height" : "180.43",
"weight" : "76.3",
"birth_date" : "1985-08-17T17:10:01Z",
"nationality" : "Ukraine",
"credit" : [
	{  
		"type" : "MasterCard",
		"number" : "123456789101112",
		"currency" : "EUR",
		"balance" : "4321"
	}
]}))
printjson(db.collection.find({"first_name" : "Dennis", "last_name" : "Grinchenko"}).toArray())