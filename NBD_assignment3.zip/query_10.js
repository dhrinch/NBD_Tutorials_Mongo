printjson(db.collection.find({"job" : "Editor"}).toArray())
printjson(db.collection.updateMany({"job" : "Editor"}, {$unset : {"email" : 1}}))
printjson(db.collection.find({"job" : "Editor"}).toArray())
