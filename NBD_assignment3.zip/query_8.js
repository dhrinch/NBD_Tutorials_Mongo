printjson(db.collection.find({"location.city" : "Moscow"}).toArray())
printjson(
db.collection.updateMany(
	{"location.city" : "Moscow"},
	{$set : {"location.city" : "Moskwa"}}
))
printjson(db.collection.find({"location.city" : "Moskwa"}).toArray())