printjson(
db.collection.updateMany(
	{"first_name" : "Antonio"},
	{$set : {"hobby" : "table tennis"}}
))
printjson(db.collection.find({"first_name" : "Antonio"}).toArray())