printjson(db.collection.aggregate([
        { "$addFields": {
            "credit": {
              "$map": {
                "input": "$credit",
                "in": {
                  "$mergeObjects": [
                    "$$this",
                    {
                      "convertedBalance": {
                        "$toDouble": "$$this.balance"
                      }
                    }
                  ]
                }
              }
            }
          }},
        { $unwind : "$credit" },        
        {$group : { _id : "$credit.currency", sum : {$sum : "$credit.convertedBalance"}}}
    ]
).toArray())