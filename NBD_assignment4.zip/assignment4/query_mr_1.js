var mapFunction = function() {	
	var key = this.sex;
	var value = {count: 1, weight: parseFloat(this.weight), height: parseFloat(this.height)};
	emit(key, value)
};

var reduceFunction = function(key, value) {
	reducedVal = {count: 0, weight: 0, height: 0};
	
	for(var idx = 0; idx < value.length; idx++){
		reducedVal.count += value[idx].count;
		reducedVal.weight += value[idx].weight;
		reducedVal.height += value[idx].height;
	}
	return reducedVal;
};

var finalizeFunction = function(key, reducedVal){
	reducedVal.avgWeight = reducedVal.weight/reducedVal.count;
	reducedVal.avgHeight = reducedVal.height/reducedVal.count;
	return reducedVal;
};

db.collection.mapReduce(
	mapFunction,
	reduceFunction,
	{
		out: {merge : "averages"},
		finalize: finalizeFunction
	}
)

printjson(db.averages.find().toArray())
