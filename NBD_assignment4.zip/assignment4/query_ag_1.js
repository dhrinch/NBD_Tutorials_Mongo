printjson(db.collection.aggregate([
	{$group : 
		{_id : "$sex", "average height:" : 
			{$avg : {$toDouble : "$height"}},
			"average weight:" : 
			{$avg : {$toDouble : "$weight"}}
		}
	}
]).toArray())