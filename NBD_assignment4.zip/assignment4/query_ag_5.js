 printjson(db.collection.aggregate(
 [
        { "$addFields": {
            "credit": {
              "$map": {
                "input": "$credit",
                "in": {
                  "$mergeObjects": [
                    "$$this",
                    {
                      "convertedBalance": {
                        "$toDouble": "$$this.balance"
                      }
                    }
                  ]
                }
              }
            }
          }},
        { $unwind : "$credit" },
        { $match : { sex : "Female", nationality : "Poland"}},
        {$group : { _id : "$credit.currency", avgBalance : {$avg : "$credit.convertedBalance"}, total : {$sum : "$credit.convertedBalance"}}}
    ]
).toArray());