var mapFunction = function() {
	var key = this.nationality;	
	var heightM = parseFloat(this.height)/100;
	var weight = parseFloat(this.weight);
	var BMI = weight / Math.pow(heightM,2);
	var value = {count: 1, BMI: BMI};
emit(key, value);
};

var reduceFunction = function(key, value) {
	reducedVal = {count: 0, BMI: 0, minBMI: value[0].BMI, maxBMI: 0};

for (var idx = 0; idx < value.length; idx++) {
	reducedVal.count += value[idx].count;	
	reducedVal.BMI += value[idx].BMI;	

		if (value[idx].BMI < reducedVal.minBMI) {
			reducedVal.minBMI = value[idx].BMI;
		}
		if (value[idx].BMI > reducedVal.maxBMI) {
			reducedVal.maxBMI = value[idx].BMI;
		}
}

return reducedVal;
};

var finalizeFunction = function(key, reducedVal){	
	reducedVal.avgBMI = reducedVal.BMI/reducedVal.count;
	return reducedVal;
};

db.collection.mapReduce(
	mapFunction,
	reduceFunction,
	{
		out: {merge : "BMIs"},
		finalize: finalizeFunction
	}
)

printjson(db.BMIs.find().toArray())
