var mapFunction = function() {
	var key = 0;
	var value = this.job; 
		emit(key, value);
	};

var reduceFunction = function(key, value) {
	reducedVal = [];
	for(var idx = 0; idx < value.length; idx++){
		if(!reducedVal.includes(value[idx])){
			reducedVal.push(value[idx]);
		}		
	}
	return reducedVal;
};

db.collection.mapReduce (
	mapFunction,
	reduceFunction,
	{	
	out : {merge : "unique_jobs" }
	}
)	

printjson(db.unique_jobs.find().toArray())