var mapFunction = function() {	
	for (var idx = 0; idx < this.credit.length; idx++){
		var key = this.credit[idx].currency;
		var value = {count: 1, sex :this.sex, nationality: this.nationality, balance: parseFloat(this.credit[idx].balance)};
		
		emit(key, value);
	}
};

var reduceFunction = function(key, value) {
	reducedVal = {count: 0, sum: 0};
		
	for(var idx = 0; idx < value.length; idx++){		
		reducedVal.count += value[idx].count;
		reducedVal.sum += value[idx].balance;		
	}
	return reducedVal;
};

var finalizeFunction = function(key, reducedVal){	
	reducedVal.avgBalance = reducedVal.sum/reducedVal.count;	
	return reducedVal;
};

db.collection.mapReduce(
	mapFunction,
	reduceFunction,	
	{
		out: {merge : "balance"},
		query: {sex: "Female", nationality: "Poland"},
		finalize: finalizeFunction		
	}
)

printjson(db.balance.find().toArray())
