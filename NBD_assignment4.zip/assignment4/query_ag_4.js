printjson(db.collection.aggregate([
    { $addFields: {
        weightD : {$toDouble: "$weight"},
        heightD : {$toDouble: "$height"},
        BMI:{
            $multiply:[
              {
                $divide:[
                  "$weightD",{$pow:["$heightD",2]}
                ]
              },
              10000
            ]
          }
        }},
      
        {$group : {_id : "$nationality", "average BMI:" :
			{$avg : "$BMI"}}
        }
]).toArray())