var mapFunction = function() {	
	for (var idx = 0; idx < this.credit.length; idx++){
		var key = this.credit[idx].currency;
		var value = parseFloat(this.credit[idx].balance);
		
		emit(key, value);
	}
};

var reduceFunction = function(key, value) {	
	return Array.sum(value);
};

db.collection.mapReduce(
	mapFunction,
	reduceFunction,
	{
		out: {merge : "remaining_balance"},		
	}
)

printjson(db.remaining_balance.find().toArray())
